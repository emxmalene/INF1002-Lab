import sys

def scale(z, y):
    return list(map(lambda x: x * y, z))

def sort(z):
    return sorted(z, key=lambda x: x % 10)

def good_sales(z):
    average = sum(z) / len(z)
    return list(filter(lambda x: x > average, z))

if len(sys.argv) < 3:
    print("Usage: python script.py <list_of_numbers> <scale_factor>")
    sys.exit(1)

user_input = sys.argv[1].split(',')
list1 = [int(num) for num in user_input]
scale_factor = int(sys.argv[2])

scaled_list = scale(list1, scale_factor)
sorted_list = sort(list1)
good_sales_list = good_sales(list1)

print(f"The scaled number is: {scaled_list} The sorted numbers are: {sorted_list} The good sale numbers are: {good_sales_list}")

