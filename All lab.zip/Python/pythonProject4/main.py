import sys

# Check if argument are 3 inputs
if len(sys.argv) != 3:
    print("Your input is invalid!")
    sys.exit(1)

try:
