import sys

def check_elfish(x, check="elf"):
    if not check:
        return True

    if check[0] in x:
        return check_elfish(x, check[1:])
    return False

user_input = sys.argv[1]

if check_elfish(user_input):
    print("%s is one elfish word!" % user_input)
else:
    print("%s is not an elfish word!" % user_input)
