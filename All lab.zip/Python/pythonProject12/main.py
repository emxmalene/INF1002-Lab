import sys
import math

n = len(sys.argv)
a = str(sys.argv[1])
b = str(sys.argv[2])
c = str(sys.argv[3])

if a.isdigit() and b.isdigit() and c.isdigit():
    add = float(a) + float(b) + float(c)
    avg = add / 3
    print("The average is: {:.2f}".format(avg))

else:
    print("Your input is invalid!")
