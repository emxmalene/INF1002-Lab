# SUM X is the summation of all positive numbers
# Recursive function: return the sum value of x
# Iterative function: return the sum value of x via for loop

import sys


# Function Recursive
def sum_recursive(x):
    if x == 0:
        return x
    else:
        return sum_recursive(x - 1) + x  # return value


# function iterative
def sum_iterative(x):
    total = 0
    for i in range(x + 1):
        total += i
    return total


def isint(x):
    try:
        int(x)
        return True
    except ValueError:
        return False


if len(sys.argv) > 1:
    if isint(sys.argv[1]):
        x = int(sys.argv[1])
    else:
        print("Your input is invalid!")
        quit()

print("The SUM value calculated by recursive is %.d and by iterative is %.d." % (sum_recursive(x), sum_iterative(x)))
