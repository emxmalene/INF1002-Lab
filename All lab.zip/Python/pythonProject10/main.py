import sys

list_input = tuple(sys.argv[1].split(','))


# Function 1: letter_count(str)
def letter_count(string, destination):
    for letters in string:
        if letters in destination:
            destination[letters] += 1
        else:
            assert isinstance(letters, object)
            destination[letters] = 1


# Function 2: double_count(str1,str2)
def double_count(str1, str2):
    store_dict = {}
    letter_count(str1, store_dict)
    letter_count(str2, store_dict)
    return store_dict


# Function 3: various count(*str)
def various_count(*str):
    store_dict = {}
    y = list(*str)
    for string in y:
        letter_count(string, store_dict)
    return store_dict


sorted_total = sorted(various_count(list_input).items(), key=lambda x: x[0], reverse=True)
output = ''

for items in sorted_total:
    output += '%s:%d' % (items[0], items[1])

print(output)
