# Digit(x): Recursive function to calculate how many digits a positive numbers has

import sys


# Function digit
def digit(x):
    if x < 10:
        return 1
    else:
        return digit(x // 10) + 1  # floor division


# Function digit iterative
def digit_iterative(x):
    count = 1
    while x >= 10:
        x = x // 10
        count += 1
    return count


# Function is int
def isint(x):
    try:
        int(x)
        return True
    except ValueError:
        return False


if len(sys.argv) > 1:
    if isint(sys.argv[1]):
        x = int(sys.argv[1])
    else:
        print("Your input is invalid!")
        quit()

print("The number of digit(s) calculated by recursive is %.d and by iterative is %.d." % (digit(x), digit_iterative(x)))
