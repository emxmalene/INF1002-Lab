import sys

double = lambda x: 2 * x
square = lambda x: x ** 2
cube = lambda x: x ** 3

user_input = int (sys.argv[1])  # user input
user_options = int (sys.argv[2]) # operation number (1,2,3)


def do_twice(x, y):  # x = function, y = input
    return x(x(y))  # inner and outer loop


if user_options == 1:  # double the number
    result = do_twice(double, user_input)
    print(result)

elif user_options == 2:  # square
    result = do_twice(square, user_input)
    print(result)

elif user_options == 3:  # cube
    result = do_twice(cube, user_input)
    print(result)

else:
    print("It cannot be supported!")
