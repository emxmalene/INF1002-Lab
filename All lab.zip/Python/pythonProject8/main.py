import sys
from myMath import *

# split the strings into a list of numbers
input_numbers = sys.argv[1].split(',')

# Defining the string name checking / converting the input into integers
numbers = [int(num) for num in input_numbers]

highest_value = maximum(numbers)
lowest_value = minimum(numbers)
diff = subtraction(highest_value, lowest_value)
summation = add(highest_value, lowest_value)
total = sumTotal(numbers)
even = evenNum(numbers)

if lowest_value < 5:
    numbers = clear(numbers)

print(
    "The difference is:%d The summation is:%d The summation of all input is:%d The number of even numbers is:%d The "
    "values in the list are: %s" % (
        diff, summation, total, even, numbers))
