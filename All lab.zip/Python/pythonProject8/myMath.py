# add function
def add(x, y):
    return x + y

# subtraction function
def subtraction(x, y):
    return x - y

# even numbers function
def evenNum(x):
    return len([num for num in x if num % 2 == 0])

# maximum number function
def maximum(x):
    return max(x)

# minimum number function
def minimum(x):
    return min(x)

# absolute function
def absolute(x):
    return abs(x)

# summation function
def sumTotal(x):
    return sum(x)

# clear function
def clear(x):
    return [0] * len(x)