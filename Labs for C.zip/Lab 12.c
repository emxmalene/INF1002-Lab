#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define RECORDSIZE 512
#define NAMSIZ 100
#define TUNMLEN 32
#define TGNMLEN 32

struct header {
    char name[NAMSIZ];
    char mode[8];
    char uid[8];
    char gid[8];
    char size[12];
    char mtime[12];
    char chksum[8];
    char linkflag;
    char linkname[NAMSIZ];
    char magic[8];
    char uname[TUNMLEN];
    char gname[TGNMLEN];
    char devmajor[8];
    char devminor[8];
};

void print_error(char *msg) {
    perror(msg);
    exit(1);
}

void add_file_to_tar(FILE *tarfile, FILE *infile, char *filename) {
    struct header header;
    memset(&header, 0, sizeof(header));
    strncpy(header.name, filename, NAMSIZ);

    fseek(infile, 0, SEEK_END);
    long filesize = ftell(infile);
    fseek(infile, 0, SEEK_SET);
    sprintf(header.size, "%011lo", (unsigned long) filesize);

    unsigned char data[RECORDSIZE];
    memset(data, 0, RECORDSIZE);
    fread(data, 1, filesize, infile);

    fwrite(&header, sizeof(header), 1, tarfile);
    fwrite(data, RECORDSIZE, filesize / RECORDSIZE + (filesize % RECORDSIZE != 0), tarfile);
}

int main(int argc, char *argv[]) {
    if (argc < 3) {
        printf("Usage: %s file1 file2 ...\n", argv[0]);
        return 1;
    }

    FILE *tarfile = fopen("Result.tar", "wb");
    if (!tarfile) {
        print_error("Error opening Result.tar");
    }

    for (int i = 1; i < argc; i++) {
        FILE *infile = fopen(argv[i], "rb");
        if (!infile) {
            print_error("Error opening input file");
        }

        add_file_to_tar(tarfile, infile, argv[i]);
        fclose(infile);
    }

    fclose(tarfile);
    return 0;
}