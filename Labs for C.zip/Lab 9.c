#include <stdio.h>
#include <string.h>
#include <ctype.h>

// function isWhitespace() which checks if a character is whitespace by using the isspace() function
int isWhitespace(char c) {
    return isspace((unsigned char)c);
}

// matchPattern() takes in a text, a pattern, and a flag for case sensitivity. It iterates through the text character by character and compares it with the pattern based on certain conditions. If the pattern is found within the text, it returns the position where the pattern starts. Otherwise, it returns -1. 
// It uses a for loop to iterate through each character of the text string. It starts from the first character and continues until it encounters the null character ('\0') indicating the end of the string.
// If the pattern string is fully matched within the text string, it returns the position where the matching starts (using i - j). Otherwise, if the loop completes without a match, it returns -1 to indicate that the pattern was not found in the text.

int matchPattern(char *text, char *pattern, int caseSensitive) {
    for (int i = 0; text[i] != '\0'; i++) {
        int j = 0;
        while (pattern[j] != '\0' && (pattern[j] == '.' || pattern[j] == text[i] || (pattern[j] == '_' && isWhitespace(text[i])) || (!caseSensitive && tolower(pattern[j]) == tolower(text[i]))) ) {
            j++;
            i++;
        }
        if (pattern[j] == '\0') {
            return i - j;
        }
    }
// When the function matchPattern() completes its execution and reaches the return -1 statement, it means that the loop has finished iterating through the text and no match was found for the given pattern.
// By returning -1, it serves as a signal to the calling code that the pattern was not found. This can be used as a condition to perform further actions based on whether a match was found or not.
    return -1;
}

int main() {
    char text[256];
    char pattern[256];
    char caseSensitiveInput;
    int caseSensitive;

    // Step 1: Read the text and pattern
    printf("Enter a line of text (up to 255 characters): \n");
    // The fgets() function takes three arguments: the variable where the input will be stored, the maximum number of characters to     read(in this case, 255), and the source from where it should read the input (in this case, the standard input stdin). It reads the input until it encounters a newline character or the maximum number of characters. After reading the input, it saves it in the      specified variable, and if the input exceeds the maximum number of characters, it will truncate the input to fit within the limit.
    fgets(text, sizeof(text), stdin);
    printf("Enter a pattern (up to 255 characters): \n");
    fgets(pattern, sizeof(pattern), stdin);

    // Remove newline characters from the input
    // The newline characters at the end of the input are removed using the strcspn() function and replacing the newline characters   with '\0' (null terminator).
    text[strcspn(text, "\n")] = '\0';
    pattern[strcspn(pattern, "\n")] = '\0';

    // Step 2: Ask for case sensitivity
    printf("Case-sensitive matching? (Y/N): \n");
    scanf(" %c", &caseSensitiveInput);
    caseSensitive = (caseSensitiveInput == 'Y' || caseSensitiveInput == 'y');

    // Step 3: Perform pattern matching
    int position = matchPattern(text, pattern, caseSensitive);

    // Step 4: Output the result
    if (position != -1) {
        printf("Matches at position %d.\n", position);
    } else {
        printf("No match.\n");
    }

    return 0;
}
