#include <stdio.h>

int main() {
  int secretNumber, guess, remainingGuesses = 10;

  // Get the secret number from Player 1
  do {
    printf("Player 1, enter a number between 1 and 1000:\n");
    scanf("%d", &secretNumber);

    if (secretNumber < 1 || secretNumber > 1000) {
      printf("That number is out of range.\n");
    }
  } while (secretNumber < 1 || secretNumber > 1000);

  // Player 2's guessing rounds
  for (int round = 1; round <= 10; round++) {
    remainingGuesses = 10 - round + 1; // Update remaining guesses for each round
    printf("Player 2, you have %d guesses remaining.\n", remainingGuesses);
    printf("Enter your guess: \n");
    scanf("%d", &guess);

    if (guess < 1 || guess > 1000) {
      printf("That number is out of range.\n");
      round--; // Decrement the round to repeat the current round
    } else if (guess < secretNumber) {
      printf("Too low.\n");
    } else if (guess > secretNumber) {
      printf("Too high.\n");
    } else {
      printf("Player 2 wins.\n");
      return 0; // Terminate the program as Player 2 has won
    }
  }

  printf("Player 1 wins.\n");

  return 0;
}